/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pgomes <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/29 05:12:26 by pgomes            #+#    #+#             */
/*   Updated: 2024/02/29 05:12:33 by pgomes           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	imprimir(char c)
{		
	write(1, &c, 1);
}

void	combinar(char a, char b, char c)
{
	imprimir(a);
	imprimir(b);
	imprimir(c);
	if (a == '7' && b == '8' && c == '9')
	{
		return ;
	}
	imprimir(',');
	imprimir(' ');
}

void	ft_print_comb(void)
{
	int	a;
	int	b;
	int	c;

	a = 0;
	while (a <= 7)
	{
		b = a + 1;
		while (b <= 8)
		{
			c = b + 1;
			while (c <= 9)
			{
				combinar(a + '0', b + '0', c + '0');
				c++;
			}
			b++;
		}
		a++;
	}
}
