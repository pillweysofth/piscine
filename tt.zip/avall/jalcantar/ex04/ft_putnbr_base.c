/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jalcatar <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/07 15:21:44 by jalcatar          #+#    #+#             */
/*   Updated: 2024/03/07 15:36:47 by jalcatar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	put_char(char c)
{
	write(1, &c, 1);
}

void	dec_to_base(int nbr, char *base, int n)
{
	if (nbr > n - 1)
		dec_to_base(nbr / n, base, n);
	put_char(base[nbr % n]);
}

void	ft_putnbr_base(int nbr, char *base)
{
	char	*buffer;
	int		n;

	n = o;
	while (*base != '\0' && *base != '+' && *base != '-')
	{
		buffer = base;
		while (*buffer++)
		{
			if (*buffer == *base)
				return ;
		}
		n++;
		base++;
	}
	if (n > 1 && *base != '+' && *base != '-')
	{
		if (nbr < 0)
		{
			nbr = -nbr;
			put_char('-');
		}
		dec_to_base(nbr, base - n, n);
	}
}
