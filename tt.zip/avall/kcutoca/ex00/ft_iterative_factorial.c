/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kcutoca <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/20 11:09:28 by kcutoca           #+#    #+#             */
/*   Updated: 2024/03/20 11:14:35 by kcutoca          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_ft_iterative_factorial(int nb)
{
	int	valor;

	valor = 1;
	if (nb < 0)
	{
		return (0);
	}
	else if (nb <= 1)
	{
		return (1);
	}
	while (nb > 0)
		valor *= nb--;
}
