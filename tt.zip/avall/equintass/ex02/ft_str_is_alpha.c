/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: equintas <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/07 12:58:33 by equintas          #+#    #+#             */
/*   Updated: 2024/03/11 21:37:30 by equintas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

int	alpha(char z)
{
	return (z >= 'a' && z <= 'z' || z >= 'A' && z <= 'Z');
}

int	ft_str_is_alpha(char *str)
{
	unsigned int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!alpha (str[i]))
		{
			return (0);
		}
		i++;
	}
	return (1);
}
