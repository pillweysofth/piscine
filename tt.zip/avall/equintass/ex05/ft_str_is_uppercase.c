/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: equintas <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/07 16:39:40 by equintas          #+#    #+#             */
/*   Updated: 2024/03/11 21:46:48 by equintas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	alpha(char M)
{
	return (M >= 'A' && M <= 'Z');
}

int	ft_str_is_uppercase(char *str)
{
	unsigned int	c;

	c = 0;
	while (str[c] != '\0')
	{
		if (!alpha (str[c]))
		{
			return (0);
		}
		c++;
	}
	return (1);
}
