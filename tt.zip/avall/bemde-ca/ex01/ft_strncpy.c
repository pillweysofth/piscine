/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bemde-ca <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/11 09:56:38 by bemde-ca          #+#    #+#             */
/*   Updated: 2024/03/13 08:14:17 by bemde-ca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int	b;

	b = 0;
	while (dest[b] != '\0' && b < n)
	{
		dest[b] = src[b];
		b++;
	}
	while (n > b)
	{
		dest[b] = '\0';
		b++;
	}
	return (dest);
}
