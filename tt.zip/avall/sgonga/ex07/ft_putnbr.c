/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sgonga <sgonga@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/29 12:48:43 by sgonga            #+#    #+#             */
/*   Updated: 2024/02/29 13:45:39 by sgonga           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
void	digiting(int num)
{
	char	digit;

	if (num / 10 != 0)
	{
		digiting(num / 10);
	}
	digit = '0' + (num % 10);
	write(1, &digit, 1);
}

void	ft_putnbr(int num)
{
	if (num < 0)
	{
		write(1, "-", 1);
		num = -num;
	}
	else if (num == 0)
	{
		write(1, "0", 1);
		return ;
	}
	digiting(num);
}

int main(void){

ft_putnbr(987562626);
return 0;
}
