#!/bin/sh
ifconfig | grep 'ether' | cut -b 15-32
