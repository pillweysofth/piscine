#!/bin/bash

git ls-files --other --ignored --exclude-standard
