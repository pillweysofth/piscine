/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_combn.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nefernan <nefernan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/20 11:20:43 by nefernan          #+#    #+#             */
/*   Updated: 2024/03/20 11:21:22 by nefernan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(STDOUT_FILENO, &c, 1);
}

void	comb(int iniciar, int n)
{
	int	i;

	if (n == 0)
	{
		ft_putchar(',');
		ft_putchar(' ');
		return ;
	}
	i = iniciar + 1;
	while (i < 10)
	{
		ft_putchar(iniciar + '0');
		ft_putchar(i + '0');
		comb(i, n - 1);
		i++;
	}
}

void	ft_print_combn(int n)
{
	comb(0, n);
}
