/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cchalumb <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/05 16:38:22 by cchalumb          #+#    #+#             */
/*   Updated: 2024/03/06 18:35:14 by cchalumb         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	orden(int *e, int *b)
{
	int	a;

	a = *e;
	*e = *b;
	*b = a;
}

void	ft_sort_int_tab(int *tab, int size)
{
	int	i;
	int	b;

	i = 1;
	while (i < size)
	{
		b = i;
		while (b > 0 && *(tab + b - 1) > *(tab + b))
		{
			orden(tab + b, tab + b - 1);
			b--;
		}
		i++;
	}
}
