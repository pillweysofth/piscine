/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cchalumb <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/05 13:25:16 by cchalumb          #+#    #+#             */
/*   Updated: 2024/03/06 18:22:48 by cchalumb         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_rev_int_tab(int *tab, int size)
{
	int	i;
	int	tamanho;

	i = 0;
	while (i < size / 2)
	{
		tamanho = tab[i];
		tab[i] = tab[size - i - 1];
		tab[size - i - 1] = tamanho;
		i++;
	}
}
