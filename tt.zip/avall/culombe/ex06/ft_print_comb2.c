/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: culombe <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/03 22:44:51 by culombe           #+#    #+#             */
/*   Updated: 2024/03/03 23:46:31 by culombe          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unitsd.h>

void	print_char(char c)
{
	write(1, &c, 1);
}

void	int_to_char(int a)
{
	int	tens;
	int	ones;

	if (a < 10)
	{
		print_char('0');
		print_char(a + '0');
	}
	else
	{
		tens = a / 10;
		ones = a % 10;
		print_char(tens + '0');
		print_char(ones + '0');
	}
}

void	ft_print_comb2(void)
{
	int	a;
	int	j;

	a = 0;
	while (a <= 99)
	{
		j = a + 1;
		while (j <= 99)
		{
			int_to_char(a);
			print_char(' ');
			int_to_char(j);
			if (i < 98)
			{
				print_char(',');
				print_char(' ');
			}
			j++;
		}
		a++;
	}
}
