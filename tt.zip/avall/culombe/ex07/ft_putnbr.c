/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: culombe <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/03 23:52:55 by culombe           #+#    #+#             */
/*   Updated: 2024/03/03 23:58:12 by culombe          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putnbr(int nb)
{
	char			sign;
	unsigned int	nb_unsigned;
	char			digit;

	if (nb < 0)
	{
		sign = -1;
		write(1, "-", 1);
	}
	else
		sign = 1;
	nb_unsigned = nb * sign;
	if (nb_unsigned > 9)
		ft_putnbr(nb_unsigned / 10);
	digit = '0' + (nb_unsigned % 10);
	write(1, &digit, 1);
}
