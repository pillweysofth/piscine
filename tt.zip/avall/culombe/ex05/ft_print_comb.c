/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: culombe <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/02 10:25:09 by culombe           #+#    #+#             */
/*   Updated: 2024/03/03 22:40:55 by culombe          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	print_character(char n)
{
	write(1, &n, 1);
}

void	print_combination(char j, char k, char l)
{
	print_character(j + '0');
	print_character(k + '0');
	print_character(l + '0');
	if (j == 7 && k == 8 && l == 9)
	{
		return ;
	}
	print_character(',');
	print_character(',');
}

void	ft_print_comb(void)
{
	int	j;
	int	k;
	int	l;

	j = 0;
	while (j <= 7)
	{
		k = j + 1;
		while (k <= 8)
		{
			l = k + 1;
			while (l <= 9)
			{
				print_combination(j, k, l);
				l++;
			}
			k++;
		}
		j++;
	}
}
int main(void)
{
ft_print_comb();
return 0;
}
