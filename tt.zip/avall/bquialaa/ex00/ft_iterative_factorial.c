/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bquiala <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/20 10:34:25 by bquiala           #+#    #+#             */
/*   Updated: 2024/03/20 11:55:33 by bquiala          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
int	ft_iterative_factorial(int nb)
{
	int	num;

	num = 1;
	if (nb < 0)
	{
		return (0);
	}
	else if (nb <= 1)
		return (num);
	while (nb > 0)
	{
		num *= nb--;
	}
	return (num);
}
