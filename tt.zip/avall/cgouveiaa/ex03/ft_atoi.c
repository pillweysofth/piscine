/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cgouveia <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/14 09:15:53 by cgouveia          #+#    #+#             */
/*   Updated: 2024/03/14 10:10:20 by cgouveia         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_atoi(char *str);

int	ft_atoi(char *str)
{
	int	number;
	int	cont_sinal;

	number = 0;
	cont_sinal = 0;
	while (*str == '-' || *str == ' ' || *str == '+')
	{
		if (*str == '-')
			cont_sinal++;
		str++;
	}
	while (*str >= '0' && *str <= '9')
	{
		number = (number * 10) + (*str - '0');
		str++;
	}
	if (cont_sinal % 2 != 0)
		number = number * (-1);
	return (number);
}
