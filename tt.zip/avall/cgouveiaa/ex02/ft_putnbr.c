/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cgouveia <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/13 11:05:20 by cgouveia          #+#    #+#             */
/*   Updated: 2024/03/13 11:37:59 by cgouveia         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putnbr(int nb);
void	ft_putchar(char c);

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putnbr(int nb)
{
	int	resto;
	int	rev;
	int	res;

	rev = 0;
	res = 0;
	while (nb != 0)
	{
		resto = nb % 10;
		rev = (rev * 10) + resto;
		nb = nb / 10;
	}
	while (rev != 0)
	{
		res = rev % 10;
		rev = rev / 10;
		ft_putchar(res + 48);
	}
}
