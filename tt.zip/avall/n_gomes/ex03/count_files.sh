#!/bin/bash
find . -type d -or -type f | wc -l
