/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dnzita <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/07 16:43:12 by dnzita            #+#    #+#             */
/*   Updated: 2024/03/11 17:20:55 by dnzita           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

char	*ft_strcapitalize(char *str)
{
	int	q;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 'a' && str[i] <= 'z')
		{
			if (i == 0)
			{
				str[i] -= 'a' + 'A' ;
			}
			else if (str[i - 1] < '0' || str[i - 1] > '9')
			{
				if (str[i - 1] < 'A' || str[i - 1] > 'Z')
				{
					if (str[i - 1] < 'a' || str[i - 1] > 'z')
					{	
						str[i] -= 'a' + 'A';
					}
				}
			}
		}
		i++;
	}
	return (str);
}
