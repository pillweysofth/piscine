#!/bin/sh
basename -s ".sh" $(find . -name "*.sh")
