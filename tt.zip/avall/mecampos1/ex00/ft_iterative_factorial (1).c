/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial (1).c                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mecampos <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/13 10:15:35 by mecampos          #+#    #+#             */
/*   Updated: 2024/03/13 10:15:41 by mecampos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_factorial(int nb)
{
	int	cur;
	int	num;

	if (nb < 0)
		return (0);
	if (nb == 0)
		return (1);
	cur = 0;
	num = 1;
	while (cur++ < nb)
		num *= cur;
	return (num);
}
