/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rodrirod <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/13 07:30:03 by rodrirod          #+#    #+#             */
/*   Updated: 2024/03/13 07:30:27 by rodrirod         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

typedef unsigned long int	t_size;

char	*ft_strncat(char *dest, char *src, unsigned int nb);

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	t_size	index;
	char	*ptr;

	ptr = dest;
	index = 0;
	while (*ptr != '\0')
	{
		ptr++;
	}
	while (*src != '\0' && index < nb)
	{
		*ptr = *src;
		ptr++;
		src++;
		index++;
	}
	*ptr = '\0';
	return (dest);
}
