/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pgomes <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/10 03:12:02 by pgomes            #+#    #+#             */
/*   Updated: 2024/03/10 03:13:03 by pgomes           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strstr(char *str, char *to_find)
{
	char	*p1;
	char	*p2;
	char	*temp;

	p1 = str;
	p2 = to_find;
	while (*p1 != '\0')
	{
		temp = p1;
		while (*p1 != '\0' && *p2 != '\0' && *p1 == *p2)
		{
			p1++;
			p2++;
		}
		if (*p2 == '\0')
		{
			return (temp);
		}
		p1 = temp + 1;
		p2 = to_find;
	}
	return (NULL);
}
int main(void)
{
printf("%s",ft_strstr(" encontrar uma",""));
return 0;
}
