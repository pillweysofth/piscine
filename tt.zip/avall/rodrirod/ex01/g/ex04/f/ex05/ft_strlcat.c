/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pgomes <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/10 03:25:15 by pgomes            #+#    #+#             */
/*   Updated: 2024/03/10 03:25:53 by pgomes           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	dest_len;
	unsigned int	src_len;

	dest_len = 0;
	src_len = 0;
	while (*dest != '\0' && dest_len < size)
	{
		dest++;
		dest_len++;
	}
	while (*src != '\0' && (dest_len < size - 1))
	{
		*dest = *src;
		src++;
		dest++;
		dest_len++;
	}
	if (dest_len < size)
	{
		dest[dest_len + src_len] = '\0';
	}
	return (dest_len + src_len);
}
