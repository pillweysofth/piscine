/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rodrirod <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/16 08:10:01 by rodrirod          #+#    #+#             */
/*   Updated: 2024/03/16 08:29:01 by rodrirod         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	unsigned int	r;

	if (d == 0)
	{
		return (0);
	}
	r = 0;
	while (s1[r] == s2[r] && s1[i] != '\0' && I < d -1)
	{
		r++;
	}
	if (s1[r] == s2[r])
	{
		return (0);
	}
	else
	{
		return (s1[r] - s2[r]);
	}
