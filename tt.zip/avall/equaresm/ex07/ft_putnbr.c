/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: equaresm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/10 21:16:14 by equaresm          #+#    #+#             */
/*   Updated: 2024/03/10 21:16:24 by equaresm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putnbr(int nb)
{
	int	divider;
	int	t;
	int	digit;

	t = nb;
	divider = 1;
	if (nb < 0)
	{
	
	if (nb == -2147483648)
	{
		write(1, "-2147483648", 11);
		return ;
	}
	ft_putchar('-');
		
		t = -nb;
	}
	while (t / divider >= 10)
		divider *= 10;
	while (divider != 0)
	{
		digit = t / divider;
		ft_putchar(digit + '0');
		t %= divider;
		divider /= 10;
	}
}
int main()
{
ft_putnbr(-2);
return 0;
}
