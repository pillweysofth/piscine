/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: equaresm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/05 03:22:57 by equaresm          #+#    #+#             */
/*   Updated: 2024/03/05 03:23:01 by equaresm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_char(char c)
{
	write(1, &c, 1);
}

void	ft_print_combination(char a, char b, char c)
{
	ft_print_char(a + '0');
	ft_print_char(b + '0');
	ft_print_char(c + '0');
	if (a == 7 && b == 8 && c == 9)
	{
		return ;
	}
	ft_print_char(',');
	ft_print_char(' ');
}

void	ft_print_comb(void)
{
	int	a;
	int	b;
	int	c;

	a = 0;
	while (a <= 7)
	{
		b = a + 1;
		while (b <= 8)
		{
			c = b + 1;
			while (c <= 9)
			{
				ft_print_combination(a, b, c);
				c++;
			}
			b++;
		}
		a++;
	}	
}
