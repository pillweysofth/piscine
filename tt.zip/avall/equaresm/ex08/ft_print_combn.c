/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   te.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: equaresm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/12 09:54:49 by equaresm          #+#    #+#             */
/*   Updated: 2024/03/12 09:55:28 by equaresm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_buffer(int i, int n, char *buffer)
{
	if (n <= 0 || n >= 10)
	{
		return ;
	}
	while (i < n)
	{
		buffer[i] = i + '0';
		i++;
	}
	buffer[i] = '\0';
}

void	ft_sp_v(void)
{
	ft_putchar(',');
	ft_putchar(' ');
}

void	ft_print_combn(int n)
{
	int		i;
	char	buffer[10];	

	ft_buffer(0, n, buffer);
	while (buffer[0] <= '9' - n + 1)
	{
		i = 0;
		while (buffer[i] != '\0')
		{
			ft_putchar(buffer[i]);
			i++;
		}
		if (buffer[0] == '9' - n + 1 && buffer[n - 1] == '9')
			return ;
		i = n - 1;
		while (i >= 0 && buffer[i] == '9' - (n - 1 - i))
			i--;
		buffer[i]++;
		while (i < n - 1)
		{
			buffer[i + 1] = buffer[i] + 1;
			i++;
		}
		ft_sp_v();
	}
}
