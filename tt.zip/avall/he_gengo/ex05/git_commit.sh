git log --format=%H -n5

