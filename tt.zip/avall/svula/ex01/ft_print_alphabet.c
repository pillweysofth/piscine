/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_alphabet.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: svula <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/29 17:42:16 by svula             #+#    #+#             */
/*   Updated: 2024/03/03 13:02:30 by svula            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	ft_print_alphabet(void)
{
	char	ft_alphabet;

	ft_alphabet = 'a';
	while (ft_alphabet <= 'z')
	{
		write(1, &ft_alphabet, 1);
		ft_alphabet ++;
	}
}
