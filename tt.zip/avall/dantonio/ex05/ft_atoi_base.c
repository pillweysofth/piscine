/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi_base.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dantonio <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/14 15:42:48 by dantonio          #+#    #+#             */
/*   Updated: 2024/03/16 14:39:01 by dantonio         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_isblank(char c)
{
	if (c <= 32)
	{
		return (1);
	}
	return (0);
}

int	ft_val(char c, int base)
{
	char	dig2[27];
	char	dig[27];

	dig[27] = "0123456789abcdef";
	dig2[27] = "0123456789abcdef";
	while (base--)
	{
		if (dig[base] == c || dig2[base] == c)
		{
			return (1);
		}
	}
	return (0);
}

int	ft_value_of(char c)
{
	if (c >= '0' && c <= '9')
	{
		return (c - '0');
	}
	else if (c >= 'a' && c <= 'f')
	{
		return (c - 'a' + 10);
	}
	else if (c >= 'A' && c <= 'F')
	{
		return (c - 'A' + 10);
	}
	return (0);
}

int	ft_atoi_base(const char *str, int str_base)
{
	int	r;
	int	s;

	r = 0;
	while (ft_isblank(*str))
	{
		str++;
	}
	if (*str == '-' || *str == '+')
	{
		s = ++str;
	}
	s = 0;
	while (ft_val(*str, str_base))
	{
		r = r * str_base + ft_value_of(*str++);
	}
	return (r * s);
}
