/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjilaias <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/15 21:29:29 by fjilaias          #+#    #+#             */
/*   Updated: 2024/03/16 11:42:04 by fjilaias         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
int	ft_atoi(char *str)
{
	int	result;
	int	sign;

	result = 0;
	sign = 1;
	while (*str == ' ' || *str >= '\t' && *str <= '\r')
	{
		str++;
	}
	while (*str == '+' || *str == '-')
		if (*(str++) == '-')
			sign *= -1;
	while (*str >= '0' && *str <= '9' && *str)
	{
		result *= 10;
		result += (sign * (*(str++) - '0'));
	}
	return (result);
}

int main(void)
{
printf("%d ",ft_atoi("\n345"));
return 0;
}
