/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjilaias <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/12 18:09:49 by fjilaias          #+#    #+#             */
/*   Updated: 2024/03/16 11:46:04 by fjilaias         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	imprimir(char c)
{
	write(1, &c, 1);
}

void	ft_putnbr(int nb)
{	
	if (nb == -2147483648)
	{
		imprimir('-');
		imprimir('2');
		nb = 147483648;
	}
	if (nb < 0)
	{
		imprimir('-');
		nb *= -1;
	}
	if (nb >= 10)
		ft_putnbr(nb / 10);
	imprimir((nb % 10) + 48);
}
int main(void)
{
ft_putnbr(2147483647);
return 0;
}
