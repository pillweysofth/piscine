/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_file.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vcatete <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/20 03:59:30 by vcatete           #+#    #+#             */
/*   Updated: 2024/03/20 03:59:42 by vcatete          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

void	ft_file(void)
{
	int		r;
	int		fd;
	char	buf[4096];

	fd = open("temddp", O_CREAT | O_RDWR | O_TRUNC, S_IWUSR | S_IRUSR);
	while (1)
	{
		r = read(0, buf, 4096);
		if (r <= 0)
			break ;
		write(fd, buf, r);
	}
	close(fd);
}
