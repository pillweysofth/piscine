#!/bin/bash
ls-file  --ignored --exclude-standard -o
