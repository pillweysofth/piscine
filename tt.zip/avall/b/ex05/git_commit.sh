#!bin/bash
git log --pretty=format:"%H" -n 5
echo 
