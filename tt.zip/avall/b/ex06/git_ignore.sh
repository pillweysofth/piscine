git ls-files --others --ignore --exclude-standard
