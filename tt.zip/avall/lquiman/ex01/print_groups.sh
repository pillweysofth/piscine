#!/bin/sh
id -G $FT_USER | tr " " "," | tr -d "\n"
