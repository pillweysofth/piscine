/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: msalembe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/11 10:38:42 by msalembe          #+#    #+#             */
/*   Updated: 2024/03/11 10:38:46 by msalembe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	len(char *str)
{
	int	c;

	c = 0;
	while (str[c] != '\0')
	{
		c++;
	}
	return (c);
}

int	ft_str_is_printable(char *str)
{
	int	i;
	int	isprintable;

	i = 0;
	isprintable = -1;
	if (len(str) == 0)
		return (1);
	while (str[i] != '\0')
	{
		if (str[i] >= 0 && str[i] <= 31)
		{
			isprintable = 0;
			break ;
		}
		isprintable = 1;
		i++;
	}
	if (isprintable)
		return (1);
	else
		return (0);
}
